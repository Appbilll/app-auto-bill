import React from 'react'
import styles from "./Taskbar.module.css"

export default function Taskbar() {
  return (
    <div className={styles.taskbar}></div>
  )
}
