import React, { useEffect, useState, useContext } from 'react'
import styles from "./Manageruser.module.css"
import axios from "axios"
import { AuthContext } from '../../../context/AuthContext'
import { Link } from "react-router-dom"
import moment from 'moment';


export default function Manageruser() {
    const [dataUser, setDataUser] = useState([])
    const { user } = useContext(AuthContext)
    const [searchTerm, setSearchTerm] = useState('');

     // Hàm xử lý khi người dùng thay đổi từ khóa tìm kiếm
     const handleSearch = (e) => {
        setSearchTerm(e.target.value);
    };

    // Lọc dữ liệu theo từ khóa tìm kiếm
    const filteredData = dataUser.filter((user) => {
        return user.username.toLowerCase().includes(searchTerm.toLowerCase());
    });

    // Tính toán thời gian còn lại
    const getRemainingTime = (item) => {
        if (!item?.isPackage.purchasedAt) {
            return 'Chưa mua';
        }

        const purchasedAt = moment(item.isPackage.purchasedAt);
        const currentTime = moment();
        const duration = moment.duration(purchasedAt.diff(currentTime));

        // Kiểm tra nếu thời hạn còn hơn thời gian hiện tại thì đánh dấu là đã hết hạn
        if (duration.asMilliseconds() < 0) {
            return 'Đã hết hạn';
        }

        // Format thời gian còn lại dưới dạng "x ngày y giờ z phút"
        const days = duration.days();
        const hours = duration.hours();
        const minutes = duration.minutes();

        return `${days} ngày ${hours} giờ ${minutes} phút`;
    };

    useEffect(() => {
        const fetchPosts = async () => {
            const token = user.token;
            if (token) {
                // Đính kèm token vào tiêu đề Authorization
                axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
                try {
                    const res = await axios.get("https://auto-bill-shop.onrender.com/api/user/")
                    setDataUser(res.data.sort((p1, p2) => {
                        return new Date(p2.createdAt) - new Date(p1.createdAt)
                    }))
                } catch (err) {
                    // Xử lý lỗi
                }
            }
        }
        fetchPosts()
    }, [user.token])

    return (
        <div className={styles.deposit}>
            <h1>Quản lí đơn nạp tiền</h1>
            <input
                type="text"
                value={searchTerm}
                onChange={handleSearch}
                placeholder="Tìm kiếm theo tên User"
                className={styles.searchInput}
            />
            <table className="table">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Avatar</th>
                        <th scope="col">Tên</th>
                        <th scope="col">Số dư</th>
                        <th scope="col">Tổng nạp</th>
                        <th scope="col">Sl Bill</th>
                        <th scope="col">Gói dịch vụ</th>
                        <th scope="col">Hành động</th>
                    </tr>
                </thead>
                <tbody>
                    {filteredData.map((item, index) => (
                        <tr key={item._id}>
                            <th scope="row">{index + 1}</th>
                            <td><img className={styles.avatar} src='https://auto-bill-shop.onrender.com/images/NoAvatar.png' alt='avatar' /></td>
                            <td>{item.username}</td>
                            <td>{item.balance}</td>
                            <td>{item.totalDeposit}</td>
                            <td>{item.products.length}</td>
                            <td>{getRemainingTime(item)}</td>
                            <td>
                                <Link to={`/profile/${item._id}`} className='link'>
                                <span className='btn-c'>Xem chi tiết</span>
                                </Link>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    )
}
